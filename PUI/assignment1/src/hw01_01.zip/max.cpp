#include <stdio.h>
#include <string>
#include <vector>
#include <queue>
#include <unordered_set>
#include <set>
#include <unordered_map>
#include <algorithm>
#include <iostream>
#include <fstream>

#include "problem.h"
 
using namespace std;

struct node {
  int cost_f;
  int cost_g;
  vector<int> operators_used;
  set<int> facts;
};
typedef struct node node_t;

struct SetHashByNum {
public:
    size_t operator()(set<int> const& st) const {
      size_t seed = st.size();
      for (const auto& elem: st) {
        seed ^= elem + 0x9e3779b9 + (seed << 6) + (seed >> 2);
      }
      return seed;
    }
};

/*struct SetEqual {
public:
    bool operator()(const std::string & str1, const std::string & str2) const {
        if (str1.length() == str2.length())
            return true;
        else
            return false;
    }
};*/

node_t a_star(strips_t &strips, node_t init, node_t goal);
int h_max_heur(strips_t &strips, node_t s, node_t goal);
bool goal_reached(node_t nd, node_t goal);
bool apply_operator(node_t &nd, strips_operator_t op);
string recreate_path(node_t init, node_t res, strips_t strips);

node_t a_star(strips_t &strips, node_t init, node_t goal){
    // open list as a priority queue that stores nodes and compares them by the f cost
    auto cmp = [](node_t left, node_t right) { return left.cost_f > right.cost_f; };
    priority_queue<node_t, vector<node_t>, decltype(cmp)> open(cmp);
    // closed list as a hashmap where key is a set of facts and value is the g cost
    unordered_map<set<int>, int, SetHashByNum> scores;

    open.push(init);
    scores[init.facts] = 0;
    while(!open.empty()){
      node_t curr_nd = open.top();
      open.pop();
      if(goal_reached(curr_nd, goal)){
        return curr_nd;
      }

      node_t succ;
      for(int i = 0; i < strips.num_operators; i++){
        succ.facts = curr_nd.facts;
        succ.operators_used = curr_nd.operators_used;
        if(apply_operator(succ, strips.operators[i])){
          //operator applied
          //Set successor_current_cost = g(node_current) + w(node_current, node_successor)
          succ.cost_g = curr_nd.cost_g + strips.operators[i].cost;
          //Add history of operators used
          succ.operators_used.push_back(i);

          auto search = scores.find(succ.facts);
          if (search == scores.end() || (succ.cost_g < search->second && search != scores.end())) {
            //not visited or cost is lower
            scores[succ.facts] = succ.cost_g;
            int cost_h = h_max_heur(strips, succ, goal);
            //if(cost_h > 0){
              succ.cost_f = succ.cost_g + cost_h;
              open.push(succ);
            //}
          }
        }
      }
    }

    return init;
}

int h_max_heur(strips_t &strips, node_t s, node_t goal){
  vector<int> deltas(strips.num_facts);
  vector<int> Us(strips.num_operators);
  set<int> C;
  set<int>::const_iterator got;
  int inf = INT32_MAX;

  //initialize deltas
  for (int i = 0; i < deltas.size(); ++i) {
    got = s.facts.find(i);
    if(got == s.facts.end()){
      deltas[i] = inf;
    }
  }

  //initialize Us
  for (int i = 0; i < strips.num_operators; ++i) {
    Us[i] = strips.operators[i].pre_size;
    //immediately apply operators with 0 pre_size
    if(strips.operators[i].pre_size == 0){
      for (int j = 0; j < strips.operators[i].add_eff_size; ++j) {
        deltas[strips.operators[i].add_eff[j]] =
            min(deltas[strips.operators[i].add_eff[j]], strips.operators[i].cost);
      }
    }
  }

  int k;
  while (!includes(C.begin(), C.end(),
                  goal.facts.begin(), goal.facts.end())){
    //get the fact that's minimal in deltas and not in C
    int min_delt_val = INT32_MAX;
    for (int i = 0; i < deltas.size(); ++i) {
      got = C.find(i);
      if(deltas[i] < min_delt_val && got == C.end()){
        k = i;
        min_delt_val = deltas[i];
      }
    }

    //add k to the set of facts
    C.insert(k);
    for (int i = 0; i < strips.num_operators; ++i) {
      for (int j = 0; j < strips.operators[i].pre_size; ++j) {
        if(k == strips.operators[i].pre[j]){
         Us[i] = Us[i] -1;
         if(Us[i] == 0){
           for (int l = 0; l < strips.operators[i].add_eff_size; ++l) {
             deltas[strips.operators[i].add_eff[l]] =
                 min(deltas[strips.operators[i].add_eff[l]],
                     strips.operators[i].cost + deltas[k]);
           }
         }
        }
      }
    }
  }

  int max_val = -1;
  for (auto elem : goal.facts){
    if(deltas[elem] > max_val) max_val = deltas[elem];
  }
  return max_val;
}

bool goal_reached(node_t nd, node_t goal){
  return includes(nd.facts.begin(), nd.facts.end(),
                  goal.facts.begin(), goal.facts.end());
}

bool apply_operator(node_t &nd, strips_operator_t op){
  set<int>::const_iterator got;

  //check for precondition
  for(int i = 0; i < op.pre_size; i++){
    got = nd.facts.find(op.pre[i]);
    if(got == nd.facts.end()){
      //doesnt have precondition
      return false;
    }
  }

  //apply add effects
  for(int i = 0; i < op.add_eff_size; i++){
    nd.facts.insert(op.add_eff[i]);
  }

  //remove del effects
  for(int i = 0; i < op.del_eff_size; i++){
    nd.facts.erase(op.del_eff[i]);
  }

  return true;
}

string recreate_path(node_t init, node_t res, strips_t strips){
  string output = ";; Cost: ";
  output = output + to_string(res.cost_g) + "\n";
  output = output + ";; h^max for init: ";
  output = output + to_string(init.cost_f) + "\n\n";

  for (long unsigned int i = 0; i < res.operators_used.size(); ++i) {
    string op_name(strips.operators[res.operators_used[i]].name);
    output = output + op_name + "\n";
  }
  return output;
}

int main(int argc, char *argv[]){
    strips_t strips;
    //fdr_t fdr;
 
    if (argc != 3){
        fprintf(stderr, "Usage: %s problem.strips problem.fdr\n", argv[0]);
        return -1;
    }
 
    // Load the planning problem in STRIPS or FDR
    stripsRead(&strips, argv[1]);
    //fdrRead(&fdr, argv[2]);
 
    // Implement the search here
    // create init and goal node
    node_t init, goal;
    for(int i = 0; i < strips.init_size; i++){
      init.facts.insert(strips.init[i]);
    }
    for(int i = 0; i < strips.goal_size; i++){
      goal.facts.insert(strips.goal[i]);
    }
    init.cost_f = h_max_heur(strips, init, goal);
    init.cost_g = 0;
    node_t res = a_star(strips, init, goal);

    string final_path = recreate_path(init, res, strips);
    cout << final_path;
    /*ofstream output_file;
    output_file.open ("example.txt");
    output_file << final_path;
    output_file.close();*/

    stripsFree(&strips);
    //fdrFree(&fdr);

    return 0;
}
