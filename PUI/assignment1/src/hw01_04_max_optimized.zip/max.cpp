#include <stdio.h>
#include <string>
#include <vector>
#include <queue>
#include <unordered_set>
#include <set>
#include <deque>
#include <unordered_map>
#include <algorithm>
#include <iostream>

#include "problem.h"
 
using namespace std;

struct node {
  int cost_f;
  int cost_g;
  int op_used_by_pred;
  struct node *pred;
  //vector<int> operators_used;
  set<int> facts;
};
typedef struct node node_t;

struct h_max_help_struct{
  int inf = INT32_MAX;
  vector<int> deltas;
  vector<int> Us;
  set<int> C;
  set<int>::const_iterator got;
  vector<vector<int>> list_of_op_prec;
};
typedef struct h_max_help_struct h_max_help_struct_t;

struct SetHashByNum {
public:
  size_t operator()(node_t const& st) const {
    size_t seed = st.facts.size();
    for (const auto& elem: st.facts) {
      seed ^= elem + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }
    return seed;
  }
};

/*struct SetHashByNum {
public:
    size_t operator()(set<int> const& st) const {
      size_t seed = st.size();
      for (const auto& elem: st) {
        seed ^= elem + 0x9e3779b9 + (seed << 6) + (seed >> 2);
      }
      return seed;
    }
};*/

struct NodeEqual {
public:
    bool operator()(const node_t & n1, const node_t & n2) const {
        if (n1.facts == n2.facts)
            return true;
        else
            return false;
    }
};

node_t a_star(strips_t &strips, node_t init, node_t goal, h_max_help_struct_t &hmax_help);
int h_max_heur(strips_t &strips, node_t s, node_t goal, h_max_help_struct_t &hmax_help);
bool goal_reached(node_t nd, node_t goal);
bool apply_operator(node_t &nd, strips_operator_t op);
string recreate_path(node_t init, node_t res, strips_t strips);
vector<vector<int>> create_op_prec(strips_t &strips);

node_t a_star(strips_t &strips, node_t init, node_t goal, h_max_help_struct_t &hmax_help){
    // open list as a priority queue that stores nodes and compares them by the f cost
    auto cmp = [](node_t left, node_t right) { return left.cost_f > right.cost_f; };
    priority_queue<node_t, vector<node_t>, decltype(cmp)> open(cmp);
    // closed list as a hashmap where key is a set of facts and value is the g cost
    //unordered_map<set<int>, int, SetHashByNum> scores;
    unordered_map<node_t, int, SetHashByNum, NodeEqual> scores;

    open.push(init);
    scores[init] = 0;
    while(!open.empty()){
      node_t curr_nd = open.top();
      open.pop();
      if(goal_reached(curr_nd, goal)){
        cout << recreate_path(init, curr_nd, strips);
        return curr_nd;
      }

      node_t succ;
      for(int i = 0; i < strips.num_operators; i++){
        succ.facts = curr_nd.facts;
        //succ.operators_used = curr_nd.operators_used;
        if(apply_operator(succ, strips.operators[i])){
          //operator applied
          //Set successor_current_cost = g(node_current) + w(node_current, node_successor)
          succ.cost_g = curr_nd.cost_g + strips.operators[i].cost;
          //Add history of operators used
          /*succ.op_used_by_pred = i;
          succ.pred = &curr_nd;*/

          auto search = scores.find(succ);
          if (search == scores.end() || (succ.cost_g < search->second && search != scores.end())) {
            //Add history of operators used
            succ.op_used_by_pred = i;
            auto search = scores.find(curr_nd);
            succ.pred = const_cast<node_t*>(&search->first);
            //not visited or cost is lower
            scores[succ] = succ.cost_g;
            int cost_h = h_max_heur(strips, succ, goal, hmax_help);
            if(cost_h != INT32_MAX){
              succ.cost_f = succ.cost_g + cost_h;
              open.push(succ);
            }
          }
        }
      }
    }

    cout << "ERROR: Path not found\n";
    return init;
}

int h_max_heur(strips_t &strips, node_t s, node_t goal, h_max_help_struct_t &hmax_help){
  //return 0;
  hmax_help.C.clear();
  //initialize deltas
  for (int i = 0; i < hmax_help.deltas.size(); ++i) {
    hmax_help.got = s.facts.find(i);
    if(hmax_help.got == s.facts.end()){
      hmax_help.deltas[i] = hmax_help.inf;
    } else{
      hmax_help.deltas[i] = 0;
    }
  }

  //initialize Us
  for (int i = 0; i < strips.num_operators; ++i) {
    hmax_help.Us[i] = strips.operators[i].pre_size;
    //immediately apply operators with 0 pre_size
    if(strips.operators[i].pre_size == 0){
      for (int j = 0; j < strips.operators[i].add_eff_size; ++j) {
        hmax_help.deltas[strips.operators[i].add_eff[j]] =
            min(hmax_help.deltas[strips.operators[i].add_eff[j]], strips.operators[i].cost);
      }
    }
  }

  int k;
  while (!includes(hmax_help.C.begin(), hmax_help.C.end(),
                  goal.facts.begin(), goal.facts.end())){
    //get the fact that's minimal in deltas and not in C
    int min_delt_val = INT32_MAX;
    for (int i = 0; i < hmax_help.deltas.size(); ++i) {
      hmax_help.got = hmax_help.C.find(i);
      if(hmax_help.deltas[i] < min_delt_val && hmax_help.got == hmax_help.C.end()){
        k = i;
        min_delt_val = hmax_help.deltas[i];
      }
    }
    if(min_delt_val == INT32_MAX) return min_delt_val;

    //add k to the set of facts
    hmax_help.C.insert(k);
    for (int i = 0; i < hmax_help.list_of_op_prec[k].size(); ++i) {
      int index_of_op = hmax_help.list_of_op_prec[k][i];
      if(hmax_help.Us[index_of_op] > 0){
        hmax_help.Us[index_of_op] = hmax_help.Us[index_of_op] - 1;
        if(hmax_help.Us[index_of_op] == 0){
          for (int j = 0; j < strips.operators[index_of_op].add_eff_size; ++j) {
            hmax_help.deltas[strips.operators[index_of_op].add_eff[j]] =
                min(hmax_help.deltas[strips.operators[index_of_op].add_eff[j]],
                    strips.operators[index_of_op].cost + hmax_help.deltas[k]);
          }
        }
      }
    }
  }

  int max_val = -1;
  for (auto elem : goal.facts){
    if(hmax_help.deltas[elem] > max_val) max_val = hmax_help.deltas[elem];
  }
  return max_val;
}

bool goal_reached(node_t nd, node_t goal){
  return includes(nd.facts.begin(), nd.facts.end(),
                  goal.facts.begin(), goal.facts.end());
}

bool apply_operator(node_t &nd, strips_operator_t op){
  set<int>::const_iterator got;

  //check for precondition
  for(int i = 0; i < op.pre_size; i++){
    got = nd.facts.find(op.pre[i]);
    if(got == nd.facts.end()){
      //doesnt have precondition
      return false;
    }
  }

  //apply add effects
  for(int i = 0; i < op.add_eff_size; i++){
    nd.facts.insert(op.add_eff[i]);
  }

  //remove del effects
  for(int i = 0; i < op.del_eff_size; i++){
    nd.facts.erase(op.del_eff[i]);
  }

  return true;
}

string recreate_path(node_t init, node_t res, strips_t strips){
  string output = ";; Cost: ";
  output = output + to_string(res.cost_g) + "\n";

  /*for (long unsigned int i = 0; i < res.operators_used.size(); ++i) {
    string op_name(strips.operators[res.operators_used[i]].name);
    output = output + op_name + "\n";
  }*/
  deque<int> path;
  node_t *curr_nd = &res;
  while (curr_nd->op_used_by_pred != -1){
    path.push_front(curr_nd->op_used_by_pred);
    curr_nd = curr_nd->pred;
  }

  output = output + ";; h^max for init: ";
  output = output + to_string(curr_nd->cost_f) + "\n\n";
  for (auto elem: path) {
    output = output + strips.operators[elem].name + "\n";
  }
  return output;
}

vector<vector<int>> create_op_prec(strips_t &strips){
  vector<vector<int>> res;
  for (int i = 0; i < strips.num_facts; ++i) {
    vector<int> tmp;
    for (int j = 0; j < strips.num_operators; ++j) {
      for (int k = 0; k < strips.operators[j].pre_size; ++k) {
        if(strips.operators[j].pre[k] == i) tmp.push_back(j);
      }
    }
    res.push_back(tmp);
  }

  return res;
}

int main(int argc, char *argv[]){
    strips_t strips;
    //fdr_t fdr;
 
    if (argc != 3){
        fprintf(stderr, "Usage: %s problem.strips problem.fdr\n", argv[0]);
        return -1;
    }
 
    // Load the planning problem in STRIPS or FDR
    stripsRead(&strips, argv[1]);
    //fdrRead(&fdr, argv[2]);
 
    // Implement the search here
    // create init and goal node
    node_t init, goal;
    for(int i = 0; i < strips.init_size; i++){
      init.facts.insert(strips.init[i]);
    }
    for(int i = 0; i < strips.goal_size; i++){
      goal.facts.insert(strips.goal[i]);
    }

    h_max_help_struct_t hmax_help;
    hmax_help.deltas.resize(strips.num_facts);
    hmax_help.Us.resize(strips.num_operators);
    //create a vector of vectors where for each fact there is a vector of operators that have the fact in its precondition
    hmax_help.list_of_op_prec = create_op_prec(strips);

    init.cost_f = h_max_heur(strips, init, goal, hmax_help);
    init.cost_g = 0;
    init.op_used_by_pred = -1;
    node_t res = a_star(strips, init, goal, hmax_help);

    //string final_path = recreate_path(init, res, strips);
    //cout << final_path;

    stripsFree(&strips);
    //fdrFree(&fdr);

    return 0;
}
