Simplest way to run the simulation is to open the project in CLion,
load the CMakeLists.txt and run the assignment2.

otherwise
mkdir build && cd build
cmake ../
cmake --build .
