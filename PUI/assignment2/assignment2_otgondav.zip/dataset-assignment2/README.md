# PUI Assignment-2 mazes

Last updated 10. 4. 2022

Naming convention: maze-size-type.txt

Maze types:
 - A - "Regular" maze
 - B - Maze with delays instead of walls
 - C - Maze with delays instead of empty space
 - E - Special maze